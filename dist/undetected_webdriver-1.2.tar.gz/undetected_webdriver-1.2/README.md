# Undetected Better Selenium

A super set of the selenium class.

### Features
1. Wait for elements to appear before interacting with it.
2. Better selection options.
3. Simplify clearing fields before sending keys.
4. Undetected